const form = document.getElementById("transactionForm");
const description = document.getElementById("description");
const amount = document.getElementById("amount");
const list = document.getElementById("transactionList");
const balanceEl = document.getElementById("balance");
const incomeEl = document.getElementById("income");
const expenseEl = document.getElementById("expense");

let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

function saveTransactions() {
  localStorage.setItem("transactions", JSON.stringify(transactions));
}

function addTransaction(event) {
  event.preventDefault();
  const transaction = {
    id: Date.now(),
    description: description.value.trim(),
    amount: Number(amount.value)
  };
  transactions.push(transaction);
  saveTransactions();
  form.reset();
  render();
}

function deleteTransaction(id) {
  transactions = transactions.filter(transaction => transaction.id !== id);
  saveTransactions();
  render();
}

function render() {
  list.innerHTML = "";
  let income = 0;
  let expense = 0;

  transactions.forEach(transaction => {
    if (transaction.amount >= 0) income += transaction.amount;
    else expense += Math.abs(transaction.amount);

    const item = document.createElement("li");
    item.innerHTML = `
      <span>${transaction.description}: $${transaction.amount.toFixed(2)}</span>
      <button class="delete" onclick="deleteTransaction(${transaction.id})">X</button>
    `;
    list.appendChild(item);
  });

  incomeEl.textContent = `$${income.toFixed(2)}`;
  expenseEl.textContent = `$${expense.toFixed(2)}`;
  balanceEl.textContent = `$${(income - expense).toFixed(2)}`;
}

form.addEventListener("submit", addTransaction);
render();
