# Expense Tracker Web App

A simple and responsive expense tracker that helps users manage income, expenses, and balance using browser local storage.

## Features

- Add income and expense transactions
- Calculate total income, expenses, and balance
- Delete transactions
- Data persists using local storage
- Clean responsive UI

## Tech Stack

- HTML5
- CSS3
- JavaScript

## How to Run

Open `index.html` in your browser.

## Learning Goal

This project demonstrates DOM manipulation, local storage, basic state management, and clean UI development.
