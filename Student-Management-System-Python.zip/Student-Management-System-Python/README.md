# Student Management System

A console-based Student Management System built with Python and SQLite. It allows users to add, view, search, update, and delete student records.

## Features

- Add new student records
- View all students
- Search student by roll number
- Update student information
- Delete student records
- Persistent SQLite database storage

## Tech Stack

- Python 3
- SQLite

## How to Run

```bash
python main.py
```

## Why This Project Matters

This project demonstrates CRUD operations, database connectivity, input validation, and clean console-based application structure.
