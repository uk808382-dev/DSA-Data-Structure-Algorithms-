import sqlite3

DB_NAME = "students.db"


def connect():
    return sqlite3.connect(DB_NAME)


def setup_database():
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                roll_no TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                department TEXT NOT NULL,
                semester INTEGER NOT NULL,
                cgpa REAL NOT NULL
            )
        """)


def add_student():
    roll_no = input("Roll No: ").strip()
    name = input("Name: ").strip()
    department = input("Department: ").strip()
    semester = int(input("Semester: "))
    cgpa = float(input("CGPA: "))

    try:
        with connect() as conn:
            conn.execute(
                "INSERT INTO students VALUES (?, ?, ?, ?, ?)",
                (roll_no, name, department, semester, cgpa)
            )
        print("Student added successfully.")
    except sqlite3.IntegrityError:
        print("A student with this roll number already exists.")


def view_students():
    with connect() as conn:
        students = conn.execute("SELECT * FROM students ORDER BY roll_no").fetchall()
    if not students:
        print("No students found.")
        return
    for student in students:
        print(student)


def search_student():
    roll_no = input("Enter roll number: ").strip()
    with connect() as conn:
        student = conn.execute("SELECT * FROM students WHERE roll_no = ?", (roll_no,)).fetchone()
    print(student if student else "Student not found.")


def update_student():
    roll_no = input("Enter roll number to update: ").strip()
    name = input("New Name: ").strip()
    department = input("New Department: ").strip()
    semester = int(input("New Semester: "))
    cgpa = float(input("New CGPA: "))

    with connect() as conn:
        cursor = conn.execute(
            "UPDATE students SET name=?, department=?, semester=?, cgpa=? WHERE roll_no=?",
            (name, department, semester, cgpa, roll_no)
        )
    print("Student updated." if cursor.rowcount else "Student not found.")


def delete_student():
    roll_no = input("Enter roll number to delete: ").strip()
    with connect() as conn:
        cursor = conn.execute("DELETE FROM students WHERE roll_no = ?", (roll_no,))
    print("Student deleted." if cursor.rowcount else "Student not found.")


def main():
    setup_database()
    while True:
        print("\n=== Student Management System ===")
        print("1. Add Student")
        print("2. View Students")
        print("3. Search Student")
        print("4. Update Student")
        print("5. Delete Student")
        print("6. Exit")
        choice = input("Choose option: ").strip()

        actions = {
            "1": add_student,
            "2": view_students,
            "3": search_student,
            "4": update_student,
            "5": delete_student,
        }
        if choice == "6":
            break
        action = actions.get(choice)
        action() if action else print("Invalid option.")


if __name__ == "__main__":
    main()
