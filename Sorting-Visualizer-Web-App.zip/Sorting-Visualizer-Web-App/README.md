# Sorting Visualizer Web App

A responsive browser-based sorting visualizer that demonstrates how common sorting algorithms work step by step.

## Features

- Visualizes Bubble Sort, Selection Sort, Insertion Sort, and Merge Sort
- Adjustable array size
- Adjustable animation speed
- Clean and responsive user interface
- Built with pure HTML, CSS, and JavaScript

## Tech Stack

- HTML5
- CSS3
- JavaScript

## How to Run

Open `index.html` in your browser.

## Learning Goal

This project helps understand sorting algorithms visually instead of only memorizing theory.
