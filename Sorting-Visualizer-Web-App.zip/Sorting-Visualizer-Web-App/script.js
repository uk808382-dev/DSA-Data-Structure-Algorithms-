let array = [];
const barsContainer = document.getElementById("bars");

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function speed() { return Number(document.getElementById("speed").value); }

function generateArray() {
  const size = Number(document.getElementById("size").value);
  array = Array.from({ length: size }, () => Math.floor(Math.random() * 350) + 20);
  renderArray();
}

function renderArray(active = []) {
  barsContainer.innerHTML = "";
  array.forEach((value, index) => {
    const bar = document.createElement("div");
    bar.className = "bar";
    if (active.includes(index)) bar.classList.add("active");
    bar.style.height = `${value}px`;
    barsContainer.appendChild(bar);
  });
}

async function bubbleSort() {
  for (let i = 0; i < array.length; i++) {
    for (let j = 0; j < array.length - i - 1; j++) {
      renderArray([j, j + 1]);
      await sleep(speed());
      if (array[j] > array[j + 1]) {
        [array[j], array[j + 1]] = [array[j + 1], array[j]];
      }
    }
  }
  renderArray();
}

async function selectionSort() {
  for (let i = 0; i < array.length; i++) {
    let minIndex = i;
    for (let j = i + 1; j < array.length; j++) {
      renderArray([minIndex, j]);
      await sleep(speed());
      if (array[j] < array[minIndex]) minIndex = j;
    }
    [array[i], array[minIndex]] = [array[minIndex], array[i]];
  }
  renderArray();
}

async function insertionSort() {
  for (let i = 1; i < array.length; i++) {
    let key = array[i];
    let j = i - 1;
    while (j >= 0 && array[j] > key) {
      array[j + 1] = array[j];
      renderArray([j, j + 1]);
      await sleep(speed());
      j--;
    }
    array[j + 1] = key;
  }
  renderArray();
}

generateArray();
