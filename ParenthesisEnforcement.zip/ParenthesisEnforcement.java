import java.util.Scanner;
import java.util.Stack;
class TreeNode {
    char data;
    TreeNode left, right;
    TreeNode(char data) {
        this.data = data;
    }
}
public class ParenthesisEnforcement{
    static int precedence(char op) {
        switch (op) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
            default:
                return -1;
        }
    }
    static TreeNode buildTree(String exp) {
        Stack<TreeNode> operands = new Stack<>();
        Stack<Character> operators = new Stack<>();
        for (int i = 0; i < exp.length(); i++) {
            char ch = exp.charAt(i);
            if (ch == ' ')
                continue;
            if (Character.isLetterOrDigit(ch)) {
                operands.push(new TreeNode(ch));
            } else if (ch == '(') {
                operators.push(ch);
            } else if (ch == ')') {
                while (operators.peek() != '(') {
                    TreeNode right = operands.pop();
                    TreeNode left = operands.pop();
                    TreeNode node = new TreeNode(operators.pop());
                    node.left = left;
                    node.right = right;
                    operands.push(node);
                }
                operators.pop();
            } else {
                while (!operators.isEmpty()
                        && operators.peek() != '('
                        && precedence(operators.peek()) >= precedence(ch)) {
                    TreeNode right = operands.pop();
                    TreeNode left = operands.pop();
                    TreeNode node = new TreeNode(operators.pop());
                    node.left = left;
                    node.right = right;
                    operands.push(node);
                }
                operators.push(ch);
            }
        }
        while (!operators.isEmpty()) {
            TreeNode right = operands.pop();
            TreeNode left = operands.pop();
            TreeNode node = new TreeNode(operators.pop());
            node.left = left;
            node.right = right;
            operands.push(node);
        }
        return operands.pop();
    }
    static void inorder(TreeNode root) {
        if (root != null) {
            if (root.left != null || root.right != null)
                System.out.print("(");
            inorder(root.left);
            System.out.print(root.data);
            inorder(root.right);
            if (root.left != null || root.right != null)
                System.out.print(")");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter an expression: ");
        String expression = sc.nextLine();

        TreeNode root = buildTree(expression);

        System.out.print("Expression with enforced parentheses: ");
        inorder(root);

        sc.close();
    }
}