# DSA Algorithm Toolkit

A command-line toolkit containing clean implementations of core Data Structures and Algorithms concepts. This project is designed for learning, revision, and technical interview preparation.

## Features

- Sorting algorithms: Bubble Sort, Selection Sort, Insertion Sort, Merge Sort, Quick Sort
- Searching algorithms: Linear Search, Binary Search
- Stack and Queue implementation
- Linked List implementation
- Time complexity reference inside code comments
- Simple CLI menu for practice

## Tech Stack

- Python 3
- Standard Library only

## Project Structure

```text
DSA-Algorithm-Toolkit/
├── main.py
├── algorithms/
│   ├── searching.py
│   └── sorting.py
├── data_structures/
│   ├── linked_list.py
│   ├── queue.py
│   └── stack.py
└── README.md
```

## How to Run

```bash
python main.py
```

## Learning Goal

The goal of this project is to strengthen DSA fundamentals and improve problem-solving skills through practical implementation.
