from algorithms.sorting import merge_sort, quick_sort
from algorithms.searching import binary_search, linear_search
from data_structures.stack import Stack
from data_structures.queue import Queue
from data_structures.linked_list import LinkedList


def demo_sorting():
    numbers = [64, 34, 25, 12, 22, 11, 90]
    print("Original:", numbers)
    print("Merge Sort:", merge_sort(numbers))
    print("Quick Sort:", quick_sort(numbers))


def demo_searching():
    numbers = [10, 20, 30, 40, 50]
    target = 30
    print("Numbers:", numbers)
    print("Linear Search index:", linear_search(numbers, target))
    print("Binary Search index:", binary_search(numbers, target))


def demo_data_structures():
    stack = Stack()
    stack.push(10)
    stack.push(20)
    print("Stack pop:", stack.pop())

    queue = Queue()
    queue.enqueue("A")
    queue.enqueue("B")
    print("Queue dequeue:", queue.dequeue())

    linked_list = LinkedList()
    linked_list.insert(5)
    linked_list.insert(10)
    linked_list.insert(15)
    print("Linked List:", linked_list.display())


def main():
    while True:
        print("\n=== DSA Algorithm Toolkit ===")
        print("1. Sorting Demo")
        print("2. Searching Demo")
        print("3. Data Structures Demo")
        print("4. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            demo_sorting()
        elif choice == "2":
            demo_searching()
        elif choice == "3":
            demo_data_structures()
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    main()
